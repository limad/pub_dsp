<?php

/* This file is part of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */

/* * ***************************Includes********************************* */
require_once dirname(__FILE__) . '/../../../../core/php/core.inc.php';

class dspsmartplug extends eqLogic {
   /*     * *************************Attributs****************************** */
	
	
	/*     * ***********************Methode static*************************** */
	public static $_client = array();
	public static $_widgetPossibility = array('custom' => true);
	public static $_confar = array(
								'Username'=>"admin",
								'soapUrl' =>"\"http://purenetworks.com/HNAP1/"
								);
	
	//public static $DSP_PORT='80';
	//public static $SOAPURL="\"http://purenetworks.com/HNAP1/"; 
/////////////////////////////////////*********************///////////////////////////////////// 
    
			
/////////////////////////////////////*********************///////////////////////////////////// 
    public function setConf($name=null,$value=null){
					
			if(isset($name)){
				//return self::Config(null,$name,$value);
				$confar2=array(
					$name=>$value,
					);
				dspsmartplug::$_confar=array_merge($confar2,dspsmartplug::$_confar);	
			//return ;
			}
		
		}
/////////////////////////////////////*********************///////////////////////////////////// 
    public function Config($param){
			if(dspsmartplug::$_confar[$param]){
				return dspsmartplug::$_confar[$param];
			}
		}
/////////////////////////////////////*********************///////////////////////////////////// 
    public function getClient() {
        //{	
			//$eqLogic = $this->getEqlogic();	
			$eqLogic = eqLogic::byType('dspsmartplug');
			
			log::add('dspsmartplug', 'debug', "getClient ".json_encode($eqLogic));
			//$ipsmartplug = $eqLogic->getConfiguration('addr');
				//$eqLogic->setConf('addr',$ipsmartplug);
			//$pass = $eqLogic->getConfiguration('pwd');
				//$eqLogic->setConf('Password',$pass);	
				
				
				$ar=array(
					'dsp_username' => config::byKey('addr'),
					'dsp_password' => config::byKey('pwd', 'dspsmartplug'),
					'user_prefix' => 'sdbg'
					);
				
				self::$_client =  new dspsmartplug(
				array(
					'dsp_username' => config::byKey('addr', 'dspsmartplug'),
					'dsp_password' => config::byKey('pwd', 'dspsmartplug'),
					'user_prefix' => 'sdbg'
					)
				);
			$vars=config::byKey('username', 79);
			log::add('dspsmartplug', 'debug', "getClient ".$vars.json_encode($ar));//.self::$_client
		//}
		try
			{
				$dsplog=dspsmartplug::soap_login("Login", config::byKey('addr', 'dspsmartplug'), config::byKey('pwd', 'dspsmartplug'));
				//$dsplog=dspsmartplug::testlogin("Login");
				//$dsplog=dspsmartplug::getdspsmartInfo();
				log::add('dspsmartplug', 'debug', "getClient ".json_encode($dsplog));
			}
		catch (Exception $ex)
			{
				$error_msg = "An error happened  while trying to retrieve your tokens \n" . $ex->getMessage() . "\n";
				log::add('dspsmartplug', 'debug', $error_msg);
			}
        return self::$_client;
        //return $ar;
	}

/////////////////////////////////////*********************///////////////////////////////////// 
    public function soap_login($action, $ipsmartplug=null, $pass=null){
			//log::add('dspsmartplug', 'debug', '    '. __FUNCTION__ .' eq: '.'-'. $ipsmartplug);
			
			if(isset($ipsmartplug)){
				$ipsmartplug=$ipsmartplug;
				$pass=$pass;
			}else{
				$ipsmartplug=self::Config('addr');
				$pass=self::Config('Password');
			}
			
			
			//log::add('dspsmartplug', 'debug', __FUNCTION__ .' started *****************');
			$xml_post_string = '<?xml version="1.0" encoding="utf-8"?>'
					.'<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
						.'<soap:Body>'
							.'<'.$action.' xmlns="http://purenetworks.com/HNAP1/">'
									.'<Action>request</Action>'
									.'<Username>'.self::Config('Username').'</Username>'
									.'<LoginPassword></LoginPassword>'
									.'<Captcha></Captcha>'
							.'</'.$action.'>'
						.'</soap:Body>'
					.'</soap:Envelope>';   // data from the form, e.g. some ID number

			$headers = array(
                        "Content-type: text/xml;charset=\"utf-8\"",
                        "Accept: text/xml",
                        "Cache-Control: no-cache",
                        "Pragma: no-cache",
                        "SOAPAction: ".self::Config('soapUrl').$action."\"",
                        "Content-length: ".strlen($xml_post_string),
                    ); 

            $url = 'http://'.$ipsmartplug.'/HNAP1/';

            // PHP cURL  for https connection with auth
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_USERPWD, Config('Username').":".$pass); // username and password - declared at the top of the doc
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
			//curl_setopt($ch, CURLOPT_COOKIESESSION, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string); // the SOAP request
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            // converting
            $response = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			
//*************************Login Phase2*******************************//////
			
			$challenge = urlencode(self::extractTagValue('Challenge', $response));	
			$sessionCookie = self::extractTagValue('Cookie', $response);
			$publickey = self::extractTagValue('PublicKey', $response);
            $loginresult = self::extractTagValue('LoginResult', $response);
			
			$privatekey =strtoupper(hash_hmac('md5', $challenge, $publickey. $pass));
			$loginpassword = strtoupper(hash_hmac('md5', $challenge, $privatekey));
					
			$SoapLogin="\"http://purenetworks.com/HNAP1/Login\"";
			
			$xml_post_string = '<?xml version="1.0" encoding="utf-8"?>'
					.'<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
						.'<soap:Body>'
							.'<Login xmlns="http://purenetworks.com/HNAP1/">'
									.'<Action>login</Action>'
									.'<Username>'.self::Config('Username').'</Username>'
									.'<LoginPassword>'.$loginpassword.'</LoginPassword>'
									.'<Captcha></Captcha>'
							.'</Login>'
						.'</soap:Body>'
					.'</soap:Envelope>';   

			$headers = array(
                        "Content-type: text/xml;charset=\"utf-8\"",
                        "Accept: text/xml",
                        "Cache-Control: no-cache",
                        "Pragma: no-cache",
						"SOAPAction: ".self::Config('soapUrl').$action."\"",
                        "Content-length: ".strlen($xml_post_string),
						"Cookie : uid=" .$sessionCookie,
                    );

            $url = 'http://'.$ipsmartplug.'/HNAP1/';
			
            // PHP cURL  for https connection with auth
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string); // the SOAP request
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            // converting
            $response = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			
			//echo "<p>response login: ". $httpcode;
	
		if($httpcode==200){
				
				$this->setConf('privK',$privatekey);
				$this->setConf('sesCookie',$sessionCookie);
			
			//log::add('dspsmartplug','debug','soap_login: '.$httpcode);
		return array('privK' => $privatekey, 'sesCookie' => $sessionCookie); 	
		
		}
		else{
		return "error";
		}
	}
/////////////////////////////////////*********************///////////////////////////////////// 
  public function syncDsp(){
			log::add('dspsmartplug', 'debug', __FUNCTION__ .' started *****************');
			return testIp();
			}
			
	
/////////////////////////////////////*********************///////////////////////////////////// 
    public function getsmartplugsetting() {
		log::add('dspsmartplug', 'debug', __FUNCTION__ .' started *****************');
		//$logfdd=dspsmartplug::soap_login("Login");
		
		//$DeviceSettings = dspsmartplug::getsmartplugInfo('GetDeviceSettings', 'GetDeviceSettingsResponse');
		//$DeviceSettings1 = dspsmartplug::getsmartplugInfo('GetDeviceSettings');
		//log::add('dspsmartplug', 'debug', "DeviceSettings 230: ".$DeviceSettings);
		//$rqst_resp1 = dspsmartplug::rqst_action('GetCurrentTemperature', 'CurrentTemperature');
		//dspsmartplug::soap_login("Login");
			$ipsmartplug = $this->getConfiguration('addr');
				dspsmartplug::setConf('addr',$ipsmartplug);
				
			/*$modelsmartplug = $this->getConfiguration('model');
				$this->setConf('model',$modelsmartplug);*/
				
			$pass = $this->getConfiguration('pwd');
				dspsmartplug::setConf('Password',$pass);
		
		
		////////////////
			
			$DeviceSettings = dspsmartplug::rqst_action('GetDeviceSettings',array('DeviceMacId','DeviceName','FirmwareVersion','ModelName','ModelDescription','HardwareVersion'));	
				log::add('dspsmartplug', 'debug', "DeviceSettings : ".json_encode($DeviceSettings));
		//////	
			
			$mac = $DeviceSettings['DeviceMacId'];
				log::add('dspsmartplug',"debug",'mac: '.$mac);
			
			$Device_Name =$DeviceSettings['DeviceName'];
				log::add('dspsmartplug',"debug",'DeviceName: '.$Device_Name);
			
			$Firmware_Version = $DeviceSettings['FirmwareVersion'];
				log::add('dspsmartplug',"debug",'FirmwareVersion: '.$Firmware_Version);
			
			$Model_Name = $DeviceSettings['ModelName'];
				log::add('dspsmartplug',"debug",'ModelName: '.$Model_Name);
			$Model_Description = $DeviceSettings['ModelDescription'];
				log::add('dspsmartplug',"debug",'ModelDescription: '.$Model_Description);
			//$DeviceSettings['VendorName']." : ".$DeviceSettings[ModelName]; //ModelDescription+ModelName;
			
			$Device_MacId = $DeviceSettings['DeviceMacId'];
				log::add('dspsmartplug',"debug",'DeviceMacId: '.$Device_MacId);
									
			$Hardware_Version = $DeviceSettings['HardwareVersion'];
				log::add('dspsmartplug',"debug",'HardwareVersion: '.$Hardware_Version);
			
			///////////
			$ScheduleSettings = dspsmartplug::rqst_action('GetScheduleSettings','ScheduleName');
				log::add('dspsmartplug', 'debug', "ScheduleSettings: ".json_encode($ScheduleSettings));
			///////////	
			$GetModuleSchedule = dspsmartplug::rqst_action('GetModuleSchedule','ScheduleName');
				log::add('dspsmartplug', 'debug', "ModuleSchedule: ".json_encode($GetModuleSchedule));
			///////////	
			$PowerSetting= dspsmartplug::rqst_action('GetPMWarningThreshold', array('Threshold','Percentage','Monthly','TotalConsumption','TimeStamp'));	
				log::add('dspsmartplug', 'debug', "PowerSetting: ".json_encode($PowerSetting));	
			///////////	GetTempMonitorSettings 
			$GetTempMonitorSettings = dspsmartplug::rqst_action('GetTempMonitorSettings','UpperBound',null,3);
				log::add('dspsmartplug', 'debug', "Temperature Warninig limit: ".json_encode($GetTempMonitorSettings)."°C");
			
			
			/* get macAddress*/
          $statecmd = dspsmartplugCmd::byEqLogicIdAndLogicalId($this->getId(),'macAddress');
          if (is_object($statecmd)) {
              if ($statecmd->execCmd() == null || $statecmd->execCmd() != $mac) {
                  $changed = true;
                  $statecmd->setCollectDate('');
                  $statecmd->event($mac);
              }
          }
           
          /* get Device_Name*/
          $statecmd = dspsmartplugCmd::byEqLogicIdAndLogicalId($this->getId(),'DeviceName');
          if (is_object($statecmd)) {
              if ($statecmd->execCmd() == null || $statecmd->execCmd() != $Device_Name) {
                  $changed = true;
                  $statecmd->setCollectDate('');
                  $statecmd->event($Device_Name);
              }
          }
	
				
	}
/////////////////////////////////////*********************///////////////////////////////////// 
    public function getsmartplugInfo($action=null, $responseTag=null, $opstat=null,$moduleParameters=null, $gateway=null) {
		
		try {
			$changed = false;
			if(isset($gateway)){
				$ipsmartplug = $gateway->getConfiguration('addr');
					$this->setConf('addr',$ipsmartplug);
				$pass = $gateway->getConfiguration('pwd');
					$this->setConf('Password',$pass);
			}else{
				$ipsmartplug = $this->getConfiguration('addr');
					$this->setConf('addr',$ipsmartplug);
				$pass = $this->getConfiguration('pwd');
					$this->setConf('Password',$pass);
			}
			log::add('dspsmartplug', 'debug', '		**** '.__FUNCTION__ .' '.$ipsmartplug.' ****  ');
			
			if(!isset($action) || $action==null){
				$rqst_resp1 = $this->rqst_action('GetCurrentTemperature', 'CurrentTemperature',null,3);
				$rqst_resp2 = $this->rqst_action("GetCurrentPowerConsumption", "CurrentConsumption",null,2);
				$rqst_resp3 = $this->rqst_action("GetSocketSettings", "OPStatus",null,1);
				$rqst_resp4 = $this->rqst_action("GetPMWarningThreshold", "TotalConsumption");
				//log::add('dspsmartplug', 'debug', "plugInfo: ".json_encode($rqst_resp1));
				
					$ar_resp=array (
							//'Params' => $privK.' : '.$sesCookie,//.' : '.$dspip.' : '.$dsppassword,
							'CurrentTemperature' => $rqst_resp1, 
							'CurrentConsumption' => $rqst_resp2,
							'OPStatus'=> $rqst_resp3,
							'TotalConsumption'=> $rqst_resp4
							);
				
				
			
			$state ="";
			$state = ($ar_resp['OPStatus'] != "true") ? "0" : "1";//(dspsmartplug::dsp_action("GetSocketSettings", "OPStatus") != "false") ? "1" : "0";//  $privatekey, $sess_Cookie, 
			log::add('dspsmartplug','debug','		state: '.$state);
			
			
			$power ="";
			$power=$Total_Conso= round($ar_resp['CurrentConsumption'], 2);
				log::add('dspsmartplug','debug','		CurrentPower: '.$power. " W");
			$Temperature="";
			$Temperature = $ar_resp['CurrentTemperature'];
				log::add('dspsmartplug','debug','		Temperature: '.$Temperature. " °C");
			
			$Total_Conso="";
			$Total_Conso= round($ar_resp['TotalConsumption']*100, 2);
			
				log::add('dspsmartplug','debug','		Total Consumption: '.$Total_Conso. " W");
			
			}
			else{
				$rqst_resp = dspsmartplug::rqst_action($action, $responseTag, $opstat, $moduleParameters);
					//log::add('dspsmartplug','debug','getsmartplugInfo : '.$action.':'.$responseTag.':'.$opstat.':'.$moduleParameters);									
				$ar_resp=array (
							//'Params' => $privK.' : '.$sesCookie,//.' : '.$dspip.' : '.$dsppassword,
							$responseTag => $rqst_resp, 
							);
				
				//return $ar_resp;
				return $rqst_resp;
				log::add('dspsmartplug', 'debug', '		*****Fin '.__FUNCTION__ .' *****		');
			}
			
			
			
			
			////////////////////////////////////////////////////////////////
			$changed = false;
			$statecmd = dspsmartplugCmd::byEqLogicIdAndLogicalId($this->getId(),'etat');
			  if (is_object($statecmd)) {
				  if ($statecmd->execCmd() == null || $statecmd->execCmd() != $state) {
					  $changed = true;
					  $statecmd->setCollectDate('');
					  $statecmd->event($state);
				  }
			  }
		   /* get Total Consumption */
			$statecmd = dspsmartplugCmd::byEqLogicIdAndLogicalId($this->getId(),'totalConso');
				  if (is_object($statecmd)) {
					  if ($statecmd->execCmd() == null || $statecmd->execCmd() != $totalConso) {
						  $changed = true;
						  $statecmd->setCollectDate('');
						  $statecmd->event($Total_Conso);
					  }
				  }
				   
			/* get currentPower */ 
			$statecmd = dspsmartplugCmd::byEqLogicIdAndLogicalId($this->getId(),'currentPower');
				  if (is_object($statecmd)) {
					  if ($statecmd->execCmd() == null || $statecmd->execCmd() != $currentPower) {
						  $changed = true;
						  $statecmd->setCollectDate('');
						  $statecmd->event($power);
					  }
				  }
			/* get currentTemperature */
			  $statecmd = dspsmartplugCmd::byEqLogicIdAndLogicalId($this->getId(),'CurrentTemperature');
			  if (is_object($statecmd)) {
				  if ($statecmd->execCmd() == null || $statecmd->execCmd() != $Temperature) {
					  $changed = true;
					  $statecmd->setCollectDate('');
					  $statecmd->event($Temperature);
				  }
			  }
			  
			  if ($changed == true){
				  $this->refreshWidget();
			  }
			  
		  
		   
        } catch (Exception $e) {
              log::add('dspsmartplugCmd','debug',$e);
      return '';
		}
  }//fin function getsmartplugInfo
/////////////////////////////////////*********************///////////////////////////////////// 
    public function rqst_action($action, $responseTag=null, $opstat=null,$moduleParameters=null){
		//log::add('dspsmartplug', 'debug', __FUNCTION__ .' started *****************');
		if (!isset($moduleParameters)) {
			$moduleParameters='1';
		}
		if (!isset($opstat)) {
			$opstat='';
		}
		
		$ipsmartplug = $this->getConfiguration('addr');
			$this->setConf('addr',$ipsmartplug);
		$pass = $this->getConfiguration('pwd');
			$this->setConf('Password',$pass);
				
		$eqLogicID = $this->getId();
        $eqLogicName = $this->getName();
		
		$login_rqst=dspsmartplug::soap_login("Login", $ipsmartplug, $pass);
		//$login_rqst=$this->soap_login("Login");
		
		$privK=$login_rqst['privK'];
		$sesCookie=$login_rqst['sesCookie'];
		
		$action_url=self::Config('soapUrl').$action."\"";
		$date = new DateTime();
		
		$timestamp = $date->getTimestamp();
		$auth = hash_hmac('md5',$timestamp.$action_url, $privK);
		$hnap_auth = strtoupper($auth." ". $timestamp);

		$xml_post_string = '<?xml version="1.0" encoding="utf-8"?>'
				.'<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
					.'<soap:Body>'
						.'<'.$action.' xmlns="http://purenetworks.com/HNAP1/">'
							.'<ModuleID>'.$moduleParameters.'</ModuleID>'
							."<NickName>Socket 1</NickName>"
							."<Description>Socket 1</Description>"
							.'<OPStatus>'.$opstat.'</OPStatus>'
							."<Controller>1</Controller>"
							//."<Duration>300</Duration>"
							//."<RadioID>RADIO_2.4GHz</RadioID>"
						.'</'.$action.'>'
				.'</soap:Envelope>';   // data from the form, e.g. some ID number

		$headers = array(
						"Content-type: text/xml;charset=\"utf-8\"",
                        "Accept: text/xml",
                        "Cache-Control: no-cache",
                        "Pragma: no-cache",
						"SOAPAction: ".self::Config('soapUrl').$action."\"",
						"HNAP_AUTH: " .$hnap_auth,
                        "Content-length: ".strlen($xml_post_string),
						"Cookie : uid=" .$sesCookie,
						//"Cookie : uid=" .getVariable("sessionCookie"),
                    ); 

        
		$url = 'http://'.$ipsmartplug.'/HNAP1/';
			
            // PHP cURL  for https connection with auth
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string); // the SOAP request
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            // converting
            $response = curl_exec($ch);
			$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			
			if (isset($responseTag)){
			return self::extractTagValue($responseTag, $response);
			}
			else {
				
			return $response;
			
			
			}
			
			
	}//fin fc dsp_action
/////////////////////////////////////*********************///////////////////////////////////// 
    
    public function extractTagValue($tag, $xmlstring){ 
		$array_resp=array();
		$listzone='';
		$doc = new DOMDocument;
		$doc->loadXML($xmlstring);
		
		if(is_array($tag)){
			foreach ($tag as $key) {
			$node = $doc->getElementsByTagName($key); 
				for($c = 0; $c<$node->length; $c++){ 
						///$text[$c] =$doc->saveXML($node->item($c)); 
						//$value[$c] = $doc->saveXML($tagvalues->item($c));
						//$listzone[$c] =  $doc->saveXML($tagvalues->item($c));
					foreach ($node as $tagvalue) {
						$value= $tagvalue->nodeValue; PHP_EOL;
					}
				$tagsarray=array($key=>$value);
				$listzone=$value[$c] .'|'.$listzone;
				} 
				$array_resp=array_merge($array_resp, $tagsarray);
			}
			return $array_resp;
			
			} 
		else{
			$nodes = $doc->getElementsByTagName($tag);
			if($nodes->length>1){
				foreach ($nodes as $tagvalue) {
					$value= $tagvalue->nodeValue;
					$tagsarray=array($value);
					$array_resp=array_merge($array_resp,$tagsarray);
				} 
				return $array_resp;
			}			
			else{
				foreach ($nodes as $tagvalue) {
					$value= $tagvalue->nodeValue;
				}
				return $value;
			}	
		}
	} 
/////////////////////////////////////*********************///////////////////////////////////// 


    public static function cron($_eqlogic_id = null) {
			
          if($_eqlogic_id !== null){
              $eqLogics = array(eqLogic::byId($_eqlogic_id));
          }
          else{
              $eqLogics = eqLogic::byType('dspsmartplug');
          }
          foreach($eqLogics as $eqLogic) {
              if ($eqLogic->getIsEnable() == 1) {
                  
                  $eqLogicID = $eqLogic->getId();
                  $eqLogicName = $eqLogic->getName();
                  //log::add('dspsmartplug', 'info', __FUNCTION__ .' started... Equipement : '.$eqLogicName.'(ID '.$eqLogicID.')' );
                  log::add('dspsmartplug', 'info', '  ********** '.__FUNCTION__ .' started... Equipement : '.$eqLogicName.'(ID '.$eqLogicID.')'.' **********  ');
              
              $eqLogicinfo = $eqLogic->getsmartplugInfo();//ok
              
              
              
              //$eqLogicinfo = $eqLogic->getsmartplugInfo(null, null, null, null, $eqLogic);
              //$eqLogic->cronHourly();
              }
          }

          return;
      }
      
/////////////////////////////////////*********************/////////////////////////////////////       
	 public static function cron5($_eqlogic_id = null) {
			
          if($_eqlogic_id !== null){
              $eqLogics = array(eqLogic::byId($_eqlogic_id));
          }
          else{
              $eqLogics = eqLogic::byType('dspsmartplug');
          }
          foreach($eqLogics as $eqLogic) {
              if ($eqLogic->getIsEnable() == 1) {
                  
                  $eqLogicID = $eqLogic->getId();
                  $eqLogicName = $eqLogic->getName();
                  //log::add('dspsmartplug', 'info', __FUNCTION__ .' started... Equipement : '.$eqLogicName.'(ID '.$eqLogicID.')' );
                  log::add('dspsmartplug', 'info', '  ********** '.__FUNCTION__ .' started... Equipement : '.$eqLogicName.'(ID '.$eqLogicID.')'.' **********  ');
              
              $eqLogicinfo = $eqLogic->getsmartplugInfo();//ok
              
              
              
              //$eqLogicinfo = $eqLogic->getsmartplugInfo(null, null, null, null, $eqLogic);
              
              }
          }

          return;
      }
	
	/////////////////////////////////////*********************///////////////////////////////////// 
    public static function cronHourly($_eqlogic_id = null) {
			
          if($_eqlogic_id !== null){
              $eqLogics = array(eqLogic::byId($_eqlogic_id));
          }
          else{
              $eqLogics = eqLogic::byType('dspsmartplug');
          }
          foreach($eqLogics as $eqLogic) {
              if ($eqLogic->getIsEnable() == 1) {
                  
                  $eqLogicID = $eqLogic->getId();
                  $eqLogicName = $eqLogic->getName();
                  
              log::add('dspsmartplug', 'debug', '  ********** '. __FUNCTION__ .' Plug : '.$eqLogicName .' **********  ');   
              //$eqLogicinfo = $eqLogic->getsmartplugInfo();//ok
              //$eqLogicinfo = $eqLogic->getsmartplugInfo(null, null, null, null, $eqLogic);
              $isConnected = $eqLogic->testIp($eqLogic);
              
              
              
              }
          }

          return;
      }
/////////////////////////////////////*********************///////////////////////////////////// 
	public static function cronDaily() {
		
		$eqLogics = eqLogic::byType('dspsmartplug');
		foreach($eqLogics as $eqLogic) {
			if ($eqLogic->getIsEnable() == 1) {
				$eqLogicID = $eqLogic->getId();
				$eqLogicName = $eqLogic->getName();
				
                //$eqLogicinfo = $eqLogic->getsmartplugInfo();
				$eqLogicsetting = $eqLogic->getsmartplugsetting();
				log::add('dspsmartplug', 'debug', __FUNCTION__ .' started... Equipement : '.$eqLogicName.'(ID '.$eqLogicID.')' );
			}
		}
		return;
	}
	  
/////////////////////////////////////*********************///////////////////////////////////// 
    public function testlogin($method) {
		log::add('dspsmartplug', 'debug', __FUNCTION__ .' started *****************');
		
		$eqLogic = $this->getEqlogic();
		$ipsmartplug = $eqLogic->getConfiguration('addr');
				$eqLogic->setConf('addr',$ipsmartplug);
		$pass = $eqLogic->getConfiguration('pwd');
				$eqLogic->setConf('Password',$pass);
          
        try
			{	
				$logdsp = dspsmartplug::soap_login($method, $ipsmartplug, $pass);
				$result="success";
				log::add('dspsmartplug', 'debug', "f testlogin login Ok:".json_encode($logdsp));
				
			}
		catch (Exception $ex)
			{	
				$result="error";
				$error_msg = "getClient Ereur while trying to retrieve your tokens \n" .$ex->getMessage() . "\n";
				log::add('dspsmartplug', 'debug', $error_msg);
			}
				
		return $result;
        //return self::$_client;
        //return $tok;
   }
	
/////////////////////////////////////*********************///////////////////////////////////// 
    public function preInsert() {
        $this->setCategory('energy', 1);
        
    }
//////////////////////////////////////*********************///////////////////////////////////// 
    public function postInsert() {
        
    }
/////////////////////////////////////*********************///////////////////////////////////// 
    public function preSave() {
			
			
    }
/////////////////////////////////////*********************///////////////////////////////////// 
    public function postSave() {
        
        if (!$this->getId())
            return;
        
        /* ----------------------------*/
        /*       commande commune      */
        /* ----------------------------*/
        
        /* etat */
        $etat = $this->getCmd(null, 'etat');
        if (!is_object($etat)) {
            $etat = new dspsmartplugCmd();
            $etat->setLogicalId('etat');
            $etat->setName(__('Etat', __FILE__));
        }
        $etat->setType('info');
        $etat->setIsVisible(1);
        $etat->setDisplay('generic_type','ENERGY_STATE');
        $etat->setSubType('binary');
        $etat->setEqLogic_id($this->getId());
        $etat->save();
        $etatid = $etat->getId();
        
         /* on */
        $on = $this->getCmd(null, 'on');
        if (!is_object($on)) {
            $on = new dspsmartplugCmd();
            $on->setLogicalId('on');
            $on->setName(__('On', __FILE__));
        }
        $on->setType('action');
        $on->setIsVisible(0);
        $on->setDisplay('generic_type','ENERGY_ON');
        $on->setSubType('other');
        $on->setEqLogic_id($this->getId());
        $on->setValue($etatid);
        $on->save();
        
         /* off */
        $off = $this->getCmd(null, 'off');
        if (!is_object($off)) {
            $off = new dspsmartplugCmd();
            $off->setLogicalId('off');
            $off->setName(__('Off', __FILE__));
        }
        $off->setType('action');
        $off->setIsVisible(0);
        $off->setDisplay('generic_type','ENERGY_OFF');
        $off->setSubType('other');
        $off->setEqLogic_id($this->getId());
        $off->setValue($etatid);
        $off->save();
        
        /* current Temperature */
           
            $currentTemp = $this->getCmd(null, 'CurrentTemperature');
            if (!is_object($currentTemp)) {
                $currentTemp = new dspsmartplugCmd();
                $currentTemp->setLogicalId('CurrentTemperature');
                $currentTemp->setIsVisible(1);
                $currentTemp->setName(__('Current Temperature', __FILE__));
            }
            $currentTemp->setType('info');
            $currentTemp->setSubType('numeric');
            $currentTemp->setEqLogic_id($this->getId());
            $currentTemp->save();
			$currentTempid = $currentTemp->getId();
			
		            
            /* current power */
            
            $currentpower = $this->getCmd(null, 'currentPower');
            if (!is_object($currentpower)) {
                $currentpower = new dspsmartplugCmd();
                $currentpower->setLogicalId('currentPower');
                $currentpower->setIsVisible(1);
                $currentpower->setName(__('Current Power', __FILE__));
            }
            $currentpower->setType('info');
            $currentpower->setSubType('numeric');
            $currentpower->setEqLogic_id($this->getId());
            $currentpower->save();
            
            /* total Conso */

			  $totalconso = $this->getCmd(null, 'totalConso');
            if (!is_object($totalconso)) {
                $totalconso = new dspsmartplugCmd();
                $totalconso->setLogicalId('totalConso');
                $totalconso->setIsVisible(1);
                $totalconso->setName(__('Conso total', __FILE__));
            }
            $totalconso->setType('info');
            $totalconso->setSubType('numeric');
            $totalconso->setEqLogic_id($this->getId());
            $totalconso->save();
			
			/* 
		nightmodeon 
		 
        $nightmodeon = $this->getCmd(null, 'nightmodeon');
        if (!is_object($nightmodeon)) {
            $nightmodeon = new dspsmartplugCmd();
            $nightmodeon->setLogicalId('nightmodeon');
            $nightmodeon->setName(__('NightModeOn', __FILE__));
        }
        $nightmodeon->setType('action');
        $nightmodeon->setIsVisible(0);
        $nightmodeon->setDisplay('generic_type','ENERGY_ON');
        $nightmodeon->setSubType('other');
        $nightmodeon->setEqLogic_id($this->getId());
        $nightmodeon->setValue($nightmodeid);
        $nightmodeon->save();
		*/	
			
        /* refresh */
        $refresh = $this->getCmd(null, 'refresh');
        if (!is_object($refresh)) {
            $refresh = new dspsmartplugCmd();
            $refresh->setLogicalId('refresh');
            $refresh->setIsVisible(1);
            $refresh->setName(__('Rafraichir', __FILE__));
        }
        $refresh->setType('action');
        $refresh->setSubType('other');
        $refresh->setEqLogic_id($this->getId());
        $refresh->save();
        
                     
               
        /* add mac Adresse */
        
        $macAddress = $this->getCmd(null, 'macAddress');
        if (!is_object($macAddress)) {
            $macAddress = new dspsmartplugCmd();
            $macAddress->setLogicalId('macAddress');
            $macAddress->setIsVisible(1);
            $macAddress->setName(__('macAddress', __FILE__));
        }
        $macAddress->setType('info');
        $macAddress->setSubType('other');
        $macAddress->setEqLogic_id($this->getId());
        $macAddress->save();
        
        
        /* add DeviceName */
        
        $DeviceName = $this->getCmd(null, 'DeviceName');
        if (!is_object($DeviceName)) {
            $DeviceName = new dspsmartplugCmd();
            $DeviceName->setLogicalId('DeviceName');
            $DeviceName->setIsVisible(1);
            $DeviceName->setName(__('DeviceName', __FILE__));
        }
        $DeviceName->setType('info');
        $DeviceName->setSubType('other');
        $DeviceName->setEqLogic_id($this->getId());
        $DeviceName->save();

        
        $model = $this->getConfiguration('model');
       
        
	}
   
/*	  /////// ***********************         *************************** ///////	*/


   
    public function testIp(){
        
        $host =  $this->getConfiguration('addr');
        //log::add('dspsmartplug', 'debug', '		********* '. __FUNCTION__ .' started ********* @IP: '.$host);
        
        $fsock = fsockopen($host, '80', $errno, $errstr, 10   );
        if (! $fsock ) {
            fclose($fsock);
            log::add('dspsmartplug', 'error','@IP : '. $host.' est injoignable' );
            throw new Exception(__('Communication error check @IP ',__FILE__));
		}else{
			log::add('dspsmartplug', 'debug', '		********* '. 'IP: '.$host.' Connected ********* ');
			
		}
        fclose($fsock);
    }

    public function preUpdate() {
        // $this->testIp();
        //dspsmartplug::getsmartplugsetting();
         //$this->testlogin();
    }

    public function postUpdate() {
		
        
    }

    public function preRemove() {
        
    }

    public function postRemove() {
        
    }
    /* * */
    public function postAjax() {
		log::add('dspsmartplug', 'debug', __FUNCTION__ .' started *****************');
        $this->cron($this->getId());
    }

    
    
    public function toHtml($_version = 'dashboard') {
          $replace = $this->preToHtml($_version);
          if (!is_array($replace)) {
              return $replace;
          }
          
          $version = jeedom::versionAlias($_version);
          if ($this->getDisplay('hideOn' . $version) == 1) {
              return '';
          }
          
          foreach ($this->getCmd() as $cmd) {
              if ($cmd->getType() == 'info') {
                  $replace['#' . $cmd->getLogicalId() . '_history#'] = '';
                  $replace['#' . $cmd->getLogicalId() . '#'] = $cmd->execCmd();
                  $replace['#' . $cmd->getLogicalId() . '_id#'] = $cmd->getId();
                  $replace['#' . $cmd->getLogicalId() . '_collectDate#'] = $cmd->getCollectDate();
                  if ($cmd->getIsHistorized() == 1) {
                      $replace['#' . $cmd->getLogicalId() . '_history#'] = 'history cursor';
                  }
              } else {
                  $replace['#' . $cmd->getLogicalId() . '_id#'] = $cmd->getId();
              }
          }
          //widget dashboard
          //return $this->postToHtml($_version, template_replace($replace, getTemplate('core', $version, $this->getConfiguration('model'), 'dspsmartplug')));
          $this->postToHtml($_version, template_replace($replace, getTemplate('core', $version, 'H110', 'dspsmartplug')));
          return $this->postToHtml($_version, template_replace($replace, getTemplate('core', $version, 'W215', 'dspsmartplug')));
                    
      }


    /*     * **********************Getteur Setteur*************************** */
}

class dspsmartplugCmd extends cmd {
    /*     * *************************Attributs****************************** */


    /*     * ***********************Methode static*************************** */


    /*     * *********************Methode d'instance************************* */

    /*
     * Non obligatoire permet de demander de ne pas supprimer les commandes même si elles ne sont pas dans la nouvelle configuration de l'équipement envoyé en JS
      public function dontRemoveCmd() {
      return true;
      }
     */

    public function execute($_options = array()) {
        
        if ($this->getType() == '') {
            return '';
        }
        
        $action= $this->getLogicalId();
        $eqLogic = $this->getEqlogic();
        $ipsmartplug = $eqLogic->getConfiguration('addr');
			 
          
          
          
          //log::add('dspsmartplug', 'debug','action: '. $action.' '.$ipsmartplug);
          log::add('dspsmartplug', 'debug','action: '. $action.' sur: '.$eqLogic->getName().'(ID '.$eqLogic->getId().')');
		  //log::add('dspsmartplug', 'debug', $eqLogic );
        
        if ($action == 'refresh') {
            $eqLogic->cron($eqLogic->getId());
             log::add('dspsmartplug','debug','REFRESH !!! '.$eqLogic->getName().'(ID '.$eqLogic->getId().')');
        }
        
        /*  a modifier par la suite pour prendre en compte different constructeur */
        
         /* set  : on */
        if ($action == 'on') {
								
            $command = $eqLogic->getsmartplugInfo("SetSocketSettings", 'SetSocketSettingsResult', "true",'1'); 
			//$command = $eqLogic->rqst_action("SetSocketSettings", "SetSocketSettingsResult", "true"); 
           
            
            log::add('dspsmartplug','info','cmd '.$action.' is: '.json_encode($command));
            
            $eqLogic->cron($eqLogic->getId());
        }
        
                /* set  : off */
        if ($action == 'off') {
             
			$command= $eqLogic->getsmartplugInfo("SetSocketSettings", "SetSocketSettingsResult", "false","1");
            log::add('dspsmartplug','info','cmd '.$action.' is: '.json_encode($command));
            $eqLogic->cron($eqLogic->getId());
        }
        
        /* set  : nightmodeon */
		
        if ($action == 'nightmodeon') {
			$command= $eqLogic->getClient();
			log::add('dspsmartplug','info','cmd '.$action.' : '.json_encode($command));
            $eqLogic->cron($eqLogic->getId());
			
        }
        
        /* set  : Update Setting */
		
      
        /* set  : nightmodeoff */
		/*
        if ($action == 'nightmodeoff') {
            $command = '/usr/bin/python ' .dirname(__FILE__).'/../../3rparty/smartplug.py  -t '  . $ipsmartplug . ' -c nightModeOff';
             $result=trim(shell_exec($command));
           log::add('dspsmartplug','debug','cmd '.$action.' : '.json_encode($command));
            $eqLogic->cron($eqLogic->getId());
        }
		*/
        
    }
	
 

    /*     * **********************Getteur Setteur*************************** */
}

?>
