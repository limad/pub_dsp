<?php

/* This file is part of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */

/* * ***************************Includes********************************* */
require_once dirname(__FILE__) . '/../../../../core/php/core.inc.php';



//define('DSP_USER', "admin");// Ne Pas Changer
//define('DSP_Password', ''); // Mot de pass local (voir au dos du smartplug ...normalement 6 chiffre)
//define('DSP_IP', '192.168.1.54'); // IP local du Plug

define('DSP_PORT', '80');// Ne Pas Changer
define('SOAPURL', "\"http://purenetworks.com/HNAP1/");// Ne Pas Changer


class  soapdsp extends dspsmartplug {
   /*     * *************************Attributs****************************** */
	private static $_client = null;
	/*     * ***********************Methode static*************************** */
	

	//private static $sess_Cookie ='';
	//public static $conf = array();
	//public static $DSP_PORT='80';
	//public static $SOAPURL="\"http://purenetworks.com/HNAP1/"; 
		
/////////////////////////////////////*********************///////////////////////////////////// 

/*	  
	  define('DSP_Password', '532235'); // Mot de pass local (voir au dos du smartplug ...normalement 6 chiffre)
define('DSP_IP', '192.168.1.54')
     */
	 
	public function extractTagValue($tag, $xmlstring){
	
		if (isset($xmlstring)){
			$dom = new DOMDocument;
			$dom->loadXML($xmlstring);
			$tagvalues = $dom->getElementsByTagName($tag);
		
			foreach ($tagvalues as $tagvalue) {
			//$tagrep= 
			return $tagvalue->nodeValue; PHP_EOL;
			//echo $tagrep;
			}	
		
			/*    OR      
			for($c = 0; $c<$tagvalues->length; $c++){
				$text[$c] =$dom->saveXML($tagvalues->item($c));
			echo $text[$c];
			}
			*/
		}
		else{
			return $tagvalue="ERROR 12";
		}	
	}
	
	
	
	
	
	
	
public function soap_login($action,$dspip=null,$dsppassword=null){
	
	$dspip = $this->getConfiguration('addr');
	$dsppassword = $this->getConfiguration('password');
	
	//dspsmartplug::$ip =$dspip;
	//dspsmartplug::setVariable('DSP_IP', $ip);
	//dspsmartplug::setVariable('DSP_Password', $dsppassword);
	//dspsmartplug::$conf=array('DSP_IPa'=> $dspip, 'DSP_Password'=> $dsppassword);
	//self::$_client=$dspip;
		
//   ************************** Login Phase 1 ****************************** //////           
			$xml_post_string = '<?xml version="1.0" encoding="utf-8"?>'
					.'<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
						.'<soap:Body>'
							.'<Login xmlns="http://purenetworks.com/HNAP1/">'
									.'<Action>request</Action>'
									.'<Username>'.DSP_USER.'</Username>'
									.'<LoginPassword></LoginPassword>'
									.'<Captcha></Captcha>'
							.'</Login>'
						.'</soap:Body>'
					.'</soap:Envelope>';   // data from the form, e.g. some ID number

			$headers = array(
                        "Content-type: text/xml;charset=\"utf-8\"",
                        "Accept: text/xml",
						"Host: ".$dspip.":".DSP_PORT,
                        "Cache-Control: no-cache",
                        "Pragma: no-cache",
                        //"SOAPAction: \"http://purenetworks.com/HNAP1/Login\"",
						"SOAPAction:".SOAPURL.$action."\"",
                        "Content-length: ".strlen($xml_post_string),
                    ); //SOAPAction: your op URL

            $url = 'http://'.$dspip.'/HNAP1/';

            // PHP cURL  for https connection with auth
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_USERPWD, DSP_USER.":".$dsppassword); // username and password - declared at the top of the doc
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
			//curl_setopt($ch, CURLOPT_COOKIESESSION, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string); // the SOAP request
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            // converting
            $response = curl_exec($ch); 
			
            curl_close($ch);
	
	
//************************* Login Phase 2 *******************************//////
			
			$challenge = urlencode(dspsmartplug::extractTagValue('Challenge', $response));	
			$sess_Cookie = dspsmartplug::extractTagValue('Cookie', $response);
			//dspsmartplug::setVariable('sess_Cookie', $sess_Cookie);
			$publickey = dspsmartplug::extractTagValue('PublicKey', $response);
            
            $loginresult = dspsmartplug::extractTagValue('LoginResult', $response);
			
			$privatekey =strtoupper(hash_hmac('md5', $challenge, $publickey.$dsppassword));
			//dspsmartplug::setVariable('privatekey', $privatekey);
			$loginpassword = strtoupper(hash_hmac('md5', $challenge, $privatekey));
					
			$SoapLogin="\"http://purenetworks.com/HNAP1/Login\"";
			
			$xml_post_string = '<?xml version="1.0" encoding="utf-8"?>'
					.'<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
						.'<soap:Body>'
							.'<Login xmlns="http://purenetworks.com/HNAP1/">'
									.'<Action>login</Action>'
									.'<Username>'.DSP_USER.'</Username>'
									.'<LoginPassword>'.$loginpassword.'</LoginPassword>'
									.'<Captcha></Captcha>'
							.'</Login>'
						.'</soap:Body>'
					.'</soap:Envelope>';   // data from the form, e.g. some ID number

			$headers = array(
                        "Content-type: text/xml;charset=\"utf-8\"",
                        "Accept: text/xml",
						"Host: ".$dspip.":".DSP_PORT,
                        "Cache-Control: no-cache",
                        "Pragma: no-cache",
						//"SOAPAction: \"http://purenetworks.com/HNAP1/Login\"",
                        "SOAPAction:".SOAPURL.$action."\"",
                        "Content-length: ".strlen($xml_post_string),
						"Cookie : uid=" .$sess_Cookie,
                    ); //SOAPAction: your op URL

            $url = 'http://'.$dspip.'/HNAP1/';
			
            // PHP cURL  for https connection with auth
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_USERPWD, DSP_USER.":".$dsppassword); // username and password - declared at the top of the doc
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
			//curl_setopt($ch, CURLOPT_COOKIESESSION, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string); // the SOAP request
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            // converting
            $response = curl_exec($ch); 
			//echo "<p>response login: ". $response;
            curl_close($ch);
			//return $privatekey;
			
			$hnapparam = array('privatekey'=>$privatekey,'sess_Cookie'=>$sess_Cookie);//, 'pie' => array('a' => 'apple')
			
			
			/*
			foreach ($hnapparam as $name => $value)
			{
            //$this->setVariable($name, $value);
            dspsmartplug::setVariable($name, $value);
			}
			
			*/
			//dspsmartplug::setVariable('Smgibv', "FG78URE01");
			//$setip= dspsmartplug::setVariable('asdfgh', "154783568");
			//$ipa = dspsmartplug::getVariable('asdfgh');
						
			//return "dddd :".json_encode($setip);//
			//return json_encode(array('privatekey'=>$privatekey,'sess_Cookie'=>$sess_Cookie));
			//var_dump(isset($a['$sess_Cookie']));
			return array('privatekey'=>$privatekey ,'sess_Cookie'=>$sess_Cookie);
}	
/*	  /////// ***********************         *************************** ///////	*/
	


	
//$xml_post,
$soapBody='<'.$action.' xmlns="http://purenetworks.com/HNAP1/">'
							.'<ModuleID>'.$moduleParameters.'</ModuleID>'
							."<NickName>Socket 1</NickName>"
							."<Description>Socket 1</Description>"
							."<OPStatus>".$act ."</OPStatus>"
							."<Controller>1</Controller>"
						.'</'.$action.'>';
						
$action=;						
						
$soapurl='http://'.$dspip.'/HNAP1/';						
						
						
						
public function action_rqst($privK, $sesCookie, $action, $responseTag, $act=null,$moduleParameters=null){	
		
		$dspip = $this->getConfiguration('addr');
		$dsppassword = $this->getConfiguration('password');
	
		log::add('dspsmartplug','debug','act_rqst: '.$dspip.":".$dsppassword.":".$privK.":".$sesCookie);
		/*
		if (!HNAP_Privatekey){
			soap_login();
		}
		*/
		if (!isset($moduleParameters)) {
			$moduleParameters='1';
		}
		if (!isset($act)) {
			$act='';
		}
		//'privatekey', $privatekey
		//$action_url="\"http://purenetworks.com/HNAP1/".$action."\"";
		$action_url=SOAPURL.$action."\"";
		$date = new DateTime();
		
		$timestamp = $date->getTimestamp();
		$auth = hash_hmac('md5',$timestamp.$action_url, $privK);
		$hnap_auth = strtoupper($auth." ". $timestamp);

		$xml_post_string = '<?xml version="1.0" encoding="utf-8"?>'
				.'<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
					.'<soap:Body>'
						.'<'.$action.' xmlns="http://purenetworks.com/HNAP1/">'
							.'<ModuleID>'.$moduleParameters.'</ModuleID>'
							."<NickName>Socket 1</NickName>"
							."<Description>Socket 1</Description>"
							."<OPStatus>".$act ."</OPStatus>"
							."<Controller>1</Controller>"
						.'</'.$action.'>'
				.'</soap:Envelope>';   // data from the form, e.g. some ID number

		$headers = array(
						"Content-type: text/xml;charset=\"utf-8\"",
                        //"Accept: text/xml",
						"Accept: text/html,application/xhtml+xml,application/xml",
						"Host: ".$dspip.":".DSP_PORT,
                        "Cache-Control: no-cache",
                        "Pragma: no-cache",
						//"SOAPAction: \"http://purenetworks.com/HNAP1/GetCurrentTemperature\"",
                        "SOAPAction:".SOAPURL.$action."\"",//SOAPAction: your op URL
						//"SOAPAction:".SOAPURL,
						"HNAP_AUTH: " .$hnap_auth,
                        "Content-length: ".strlen($xml_post_string),
						"Cookie : uid=" .$sesCookie,
                    ); 

        $url = 'http://'.$dspip.'/HNAP1/';
		//log::add('dspsmartplug','debug','url: '.$url." ".$hnap_auth);	
            // PHP cURL  for https connection with auth
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($ch, CURLOPT_USERPWD, DSP_USER.":".DSP_Password); // username and password - declared at the top of the doc
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
			//curl_setopt($ch, CURLOPT_COOKIESESSION, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string); // the SOAP request
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            // converting
            $response = curl_exec($ch);
			//echo "<p>response temp:" .$response;		
			curl_close($ch);
			return $response;
			//return dspsmartplug::extractTagValue($responseTag, $response);
			
	}//fin fc dsp_action

	
/*
	public function getVariable($name, $default = NULL){
		return isset($conf[$name]) ? $conf[$name] : $default;
	}// fin function getVariable(

    public function setVariable($name, $value){
		dspsmartplug::$conf[$name]=$value;
		//$conf=array_push($conf[$name]=$value);
		//array_push($conf, $conf[$name]=$value);
		
		//$conf=$conf+array_push($conf[$name]=$value);
		//$conf1=$conf;
		//$conf2=$conf[$name]=$value;
		//$result = array_merge($array1, $array2);
		//$conf = array_merge($conf1,$conf2);
		
		return $conf;//$value;
	}// fin function setVariable
    */
    /* test @ip */
    
  

   

   
}


?>
